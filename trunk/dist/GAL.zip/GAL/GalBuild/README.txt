Global ALigner (GAL) is an RIA implementation of Needleman-Wunsch
global sequence alignment algorithm. GAL uses the algorithm to 
optimally align two DNA sequences according to given score matrix 
and gap penalty. GAL comprises of flex front-end and java back-end.
Communication is established via AMF3 protocol, using BlazeDS
data services.